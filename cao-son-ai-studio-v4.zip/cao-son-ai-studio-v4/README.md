# Cao Sơn AI Studio V4 — GitHub-first workspace

## V4 hoạt động theo hướng nào?

V4 ghi file **trực tiếp lên repository GitHub**, không ghi trực tiếp vào bộ nhớ điện thoại. Trình duyệt không có quyền tự ghi vào GitHub chỉ vì đang chạy trên GitHub Pages. Vì vậy cần một backend trung gian là Cloudflare Worker.

Luồng an toàn:
1. Đưa code vào trình soạn thảo (có thể lấy code do ChatGPT tạo trong cuộc trò chuyện rồi dán vào).
2. Bấm **Đưa vào hàng duyệt**.
3. Xem lại đường dẫn và nội dung.
4. Bấm **Phê duyệt & ghi GitHub**.
5. Worker commit vào nhánh `ai-work`, không sửa `main`.
6. Mở GitHub Compare: `main...ai-work`, kiểm tra diff, tạo Pull Request và merge khi đã chắc chắn.
7. GitHub Pages tiếp tục xuất bản từ `main`; sau merge và deploy, website mới cập nhật.

## Tệp
- `index.html`: giao diện V4, tự chứa CSS/JavaScript; upload vào root repository GitHub Pages.
- `worker.js`: backend GitHub bridge để deploy thành Cloudflare Worker.

## Cấu hình Cloudflare Worker

Worker Variables:
- `GITHUB_OWNER` = tên tài khoản/organization GitHub
- `GITHUB_REPO` = tên repository
- `GITHUB_BASE_BRANCH` = `main` (hoặc nhánh GitHub Pages đang phát hành)
- `GITHUB_AI_BRANCH` = `ai-work`
- `ALLOWED_ORIGIN` = `https://USERNAME.github.io` (chỉ origin, không thêm tên repo hay dấu `/` cuối). Nếu có nhiều origin, ngăn cách bằng dấu phẩy.

Worker Secrets:
- `GITHUB_TOKEN` = Fine-grained Personal Access Token giới hạn đúng một repository, chỉ bật **Contents: Read and write**.
- `ADMIN_TOKEN` = chuỗi ngẫu nhiên dài, khó đoán, chỉ dùng để đăng nhập Studio.

Không đặt `GITHUB_TOKEN` trong `index.html`, không commit vào GitHub, không gửi token trong chat. Nếu token từng bị lộ, thu hồi ngay và tạo token mới.

## Cấu hình trong V4
1. Mở GitHub repository > Settings > Pages và xuất bản từ `main` / thư mục root.
2. Upload `index.html` vào root repository, commit.
3. Deploy `worker.js` lên Cloudflare Workers.
4. Nhập Variables và Secrets nói trên trong Worker Settings.
5. Mở website GitHub Pages, vào **Kết nối & cài đặt**.
6. Nhập Owner, Repo, base branch `main`, AI branch `ai-work`, Worker URL, và Admin token.
7. Bấm **Kiểm tra Worker**.
8. Vào Files & Code, tải file từ `ai-work` (lần đầu Worker sẽ tạo nhánh này từ `main`). Tạo/sửa file và đưa vào hàng duyệt.

## Token GitHub
Tạo Fine-grained token với quyền tối thiểu:
- Repository access: chỉ chọn đúng repository.
- Repository permissions: Contents = Read and write.
- Không cấp Workflows nếu không cần sửa workflow.
- Lưu token dưới dạng Worker Secret `GITHUB_TOKEN`.

## Những gì V4 làm được / chưa làm được

Đã có:
- Dashboard responsive cho điện thoại.
- Đọc danh sách file và nội dung text từ nhánh `ai-work`.
- Tạo/sửa nội dung file trong editor.
- Tải file text về điện thoại.
- Đưa thay đổi vào hàng chờ duyệt.
- Phê duyệt và commit file lên nhánh `ai-work` bằng GitHub Contents API.
- Upload ảnh vào repository qua hàng duyệt.
- Khai báo nhân sự AI và model ID dưới dạng ghi chú cục bộ.
- Phòng họp lưu nhật ký thủ công trên trình duyệt.

Chưa có:
- AI tự gọi model/API và tự thảo luận. Nhân sự AI và phòng họp hiện chỉ là giao diện/nhật ký cấu hình, không giả vờ rằng AI đang hoạt động.
- Xóa file từ repository.
- Tạo Pull Request tự động; hãy mở Compare trên GitHub để kiểm tra và tạo PR thủ công.
- Diff trực quan từng dòng.

## OpenRouter
OpenRouter Terms of Service hiện quy định người dùng phải ít nhất 18 tuổi. Vì vậy V4 không tích hợp luồng cho người chưa đủ tuổi tự đăng ký hoặc tự dùng dịch vụ này. Xem https://openrouter.ai/terms. Có thể tiếp tục tạo code trong cuộc trò chuyện ChatGPT này rồi đưa code vào V4 để duyệt và commit GitHub.

## Giới hạn kỹ thuật
- Worker chỉ cho phép ghi file tối đa 1,6 MB mỗi file ở bản này.
- Upload ảnh tối đa 1,5 MB trên giao diện.
- Các thay đổi ghi vào nhánh `ai-work`, không tự làm thay đổi website đang xuất bản từ `main`.
- GitHub Pages là hosting tĩnh; backend xử lý API phải chạy ở dịch vụ riêng như Cloudflare Workers.
- V4 dùng localStorage cho bản nháp/đội ngũ/nhật ký; dữ liệu đó nằm trên trình duyệt của thiết bị hiện tại.
