/**
 * Cao Son Studio V4 - GitHub repository bridge for Cloudflare Workers.
 * Secrets: GITHUB_TOKEN, ADMIN_TOKEN
 * Variables: GITHUB_OWNER, GITHUB_REPO, GITHUB_BASE_BRANCH=main,
 *            GITHUB_AI_BRANCH=ai-work, ALLOWED_ORIGIN=https://OWNER.github.io
 * The browser never receives the GitHub token. Writes are restricted to AI_BRANCH.
 */
const GH = 'https://api.github.com';
const MAX_BODY = 3_500_000;

function json(data, status = 200, headers = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'content-type': 'application/json; charset=utf-8', ...headers },
  });
}
function cors(request, env) {
  const origin = request.headers.get('Origin') || '';
  const allowed = String(env.ALLOWED_ORIGIN || '').split(',').map(x => x.trim()).filter(Boolean);
  const h = {
    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
    'Access-Control-Max-Age': '86400',
    'Vary': 'Origin',
  };
  if (origin && allowed.includes(origin)) h['Access-Control-Allow-Origin'] = origin;
  return h;
}
function withCors(response, request, env) {
  const h = new Headers(response.headers);
  for (const [k, v] of Object.entries(cors(request, env))) h.set(k, v);
  return new Response(response.body, { status: response.status, statusText: response.statusText, headers: h });
}
function auth(request, env) {
  const value = request.headers.get('Authorization') || '';
  const token = value.startsWith('Bearer ') ? value.slice(7) : '';
  if (!env.ADMIN_TOKEN || !token || token !== env.ADMIN_TOKEN) {
    return json({ error: 'Admin token không hợp lệ hoặc chưa được cấu hình.' }, 401);
  }
  return null;
}
function config(env) {
  const owner = String(env.GITHUB_OWNER || '').trim();
  const repo = String(env.GITHUB_REPO || '').trim();
  const base = String(env.GITHUB_BASE_BRANCH || 'main').trim();
  const branch = String(env.GITHUB_AI_BRANCH || 'ai-work').trim();
  if (!owner || !repo || !env.GITHUB_TOKEN || !env.ADMIN_TOKEN) throw new Error('Thiếu GITHUB_OWNER, GITHUB_REPO, GITHUB_TOKEN hoặc ADMIN_TOKEN trong Worker.');
  if (!/^[A-Za-z0-9_.-]{1,100}$/.test(owner) || !/^[A-Za-z0-9_.-]{1,100}$/.test(repo)) throw new Error('Owner hoặc repository không hợp lệ.');
  if (!/^[A-Za-z0-9._/-]{1,100}$/.test(base) || !/^[A-Za-z0-9._/-]{1,100}$/.test(branch) || branch === base) throw new Error('Tên nhánh không hợp lệ. Nhánh AI phải khác nhánh Pages.');
  return { owner, repo, base, branch };
}
function validPath(p) {
  if (typeof p !== 'string' || !p || p.length > 220 || p.startsWith('/') || p.includes('\\') || p.includes('\0')) return false;
  const seg = p.split('/');
  if (seg.some(x => !x || x === '.' || x === '..')) return false;
  const low = p.toLowerCase();
  if (low.startsWith('.git/') || low.startsWith('.github/') || low.startsWith('.dev.vars') || low.startsWith('.env') || low.includes('/.env') || low.includes('secret')) return false;
  if (['worker.js', 'wrangler.toml', 'wrangler.json', 'wrangler.jsonc'].includes(low)) return false;
  return true;
}
function encodePath(p) { return p.split('/').map(encodeURIComponent).join('/'); }
async function readBody(request) {
  const n = Number(request.headers.get('content-length') || 0);
  if (n > MAX_BODY) throw new Error('Nội dung gửi lên vượt giới hạn 3,5 MB.');
  const text = await request.text();
  if (text.length > MAX_BODY) throw new Error('Nội dung gửi lên vượt giới hạn 3,5 MB.');
  return text ? JSON.parse(text) : {};
}
async function gh(path, env, init = {}) {
  const res = await fetch(GH + path, {
    ...init,
    headers: {
      'Authorization': `Bearer ${env.GITHUB_TOKEN}`,
      'Accept': 'application/vnd.github+json',
      'X-GitHub-Api-Version': '2022-11-28',
      'User-Agent': 'Cao-Son-AI-Studio-V4',
      ...(init.headers || {}),
    },
  });
  const raw = await res.text();
  let data = {};
  try { data = raw ? JSON.parse(raw) : {}; } catch { data = { message: raw.slice(0, 500) }; }
  if (!res.ok) {
    const e = new Error(data.message || `GitHub API trả về HTTP ${res.status}.`);
    e.status = res.status;
    throw e;
  }
  return data;
}
async function ensureBranch(env, c) {
  const refPath = `/repos/${c.owner}/${c.repo}/git/ref/heads/${encodeURIComponent(c.branch)}`;
  try { return await gh(refPath, env); }
  catch (e) {
    if (e.status !== 404) throw e;
    const baseRef = await gh(`/repos/${c.owner}/${c.repo}/git/ref/heads/${encodeURIComponent(c.base)}`, env);
    try {
      return await gh(`/repos/${c.owner}/${c.repo}/git/refs`, env, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ref: `refs/heads/${c.branch}`, sha: baseRef.object.sha }),
      });
    } catch (createErr) {
      if (createErr.status === 422) return await gh(refPath, env);
      throw createErr;
    }
  }
}
function bytesToBase64(bytes) {
  let binary = '';
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
  return btoa(binary);
}
function utf8ToBase64(text) { return bytesToBase64(new TextEncoder().encode(text)); }
async function route(request, env) {
  const url = new URL(request.url);
  if (request.method === 'OPTIONS') return new Response(null, { status: 204 });
  const denied = auth(request, env);
  if (denied) return denied;
  let c;
  try { c = config(env); } catch (e) { return json({ error: e.message }, 500); }
  try {
    if (url.pathname === '/api/health' && request.method === 'GET') {
      return json({ ok: true, owner: c.owner, repo: c.repo, baseBranch: c.base, aiBranch: c.branch, mode: 'github-bridge' });
    }
    if (url.pathname === '/api/tree' && request.method === 'GET') {
      await ensureBranch(env, c);
      const path = url.searchParams.get('path') || '';
      if (path && !validPath(path)) return json({ error: 'Đường dẫn không hợp lệ.' }, 400);
      const p = path ? '/' + encodePath(path) : '';
      const items = await gh(`/repos/${c.owner}/${c.repo}/contents${p}?ref=${encodeURIComponent(c.branch)}`, env);
      if (!Array.isArray(items)) return json({ error: 'Đường dẫn này là file, không phải thư mục.' }, 400);
      return json({ items: items.map(x => ({ name: x.name, path: x.path, type: x.type, size: x.size, sha: x.sha })) });
    }
    if (url.pathname === '/api/file' && request.method === 'GET') {
      await ensureBranch(env, c);
      const path = url.searchParams.get('path') || '';
      if (!validPath(path)) return json({ error: 'Đường dẫn file không hợp lệ.' }, 400);
      const f = await gh(`/repos/${c.owner}/${c.repo}/contents/${encodePath(path)}?ref=${encodeURIComponent(c.branch)}`, env);
      if (Array.isArray(f) || !f.content) return json({ error: 'Không đọc được nội dung file này.' }, 400);
      const binary = atob(f.content.replace(/\s/g, ''));
      const bytes = Uint8Array.from(binary, ch => ch.charCodeAt(0));
      let content;
      try { content = new TextDecoder('utf-8', { fatal: true }).decode(bytes); }
      catch { return json({ error: 'File này là nhị phân. Hãy dùng chức năng tải ảnh/file tương ứng.' }, 415); }
      return json({ path: f.path, sha: f.sha, content, size: f.size });
    }
    if (url.pathname === '/api/write' && request.method === 'POST') {
      const body = await readBody(request);
      const path = body.path;
      if (!validPath(path)) return json({ error: 'Đường dẫn file không hợp lệ hoặc bị bảo vệ.' }, 400);
      if (typeof body.content !== 'string') return json({ error: 'Thiếu nội dung file.' }, 400);
      const encoding = body.encoding === 'base64' ? 'base64' : 'utf8';
      const bytes = encoding === 'base64' ? Math.floor(body.content.length * 0.75) : new TextEncoder().encode(body.content).length;
      if (bytes > 1_600_000) return json({ error: 'File quá lớn. Giới hạn 1,6 MB mỗi file ở bản V4.' }, 413);
      await ensureBranch(env, c);
      let sha;
      try { const existing = await gh(`/repos/${c.owner}/${c.repo}/contents/${encodePath(path)}?ref=${encodeURIComponent(c.branch)}`, env); sha = existing.sha; }
      catch (e) { if (e.status !== 404) throw e; }
      const content = encoding === 'base64' ? body.content.replace(/^data:[^,]*,/, '').replace(/\s/g, '') : utf8ToBase64(body.content);
      const result = await gh(`/repos/${c.owner}/${c.repo}/contents/${encodePath(path)}`, env, {
        method: 'PUT', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: String(body.message || `Cao Son Studio: update ${path}`).slice(0, 120), content, branch: c.branch, ...(sha ? { sha } : {}) }),
      });
      return json({ ok: true, path, branch: c.branch, sha: result.content?.sha, commit: result.commit?.sha, html_url: result.content?.html_url });
    }
    return json({ error: 'Không tìm thấy API endpoint.' }, 404);
  } catch (e) {
    return json({ error: e.message || 'Lỗi không xác định.' }, e.status && e.status >= 400 && e.status < 600 ? e.status : 500);
  }
}
export default {
  async fetch(request, env) {
    const origin = request.headers.get('Origin') || '';
    const allowed = String(env.ALLOWED_ORIGIN || '').split(',').map(x => x.trim()).filter(Boolean);
    if (request.method !== 'OPTIONS' && origin && !allowed.includes(origin)) return json({ error: 'Origin này chưa được cho phép trong ALLOWED_ORIGIN.' }, 403);
    return withCors(await route(request, env), request, env);
  },
};
